import os

#class Config: #Error with class config.
GREET = os.environ.get("greeting")